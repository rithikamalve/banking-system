﻿using BankingSystem.Models;
using BankingSystem.Services;
using System;

namespace BankingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            var accountService = new AccountService();

            Console.WriteLine("Welcome to the Banking System!");

            while (true)
            {
                Console.WriteLine("\n1. Create Account");
                Console.WriteLine("2. Deposit");
                Console.WriteLine("3. Withdraw");
                Console.WriteLine("4. Check Balance");
                Console.WriteLine("5. View Transaction History");
                Console.WriteLine("6. Exit");
                Console.Write("Select an option: ");
                var choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        CreateAccount(accountService);
                        break;
                    case "2":
                        Deposit(accountService);
                        break;
                    case "3":
                        Withdraw(accountService);
                        break;
                    case "4":
                        CheckBalance(accountService);
                        break;
                    case "5":
                        ViewTransactionHistory(accountService);
                        break;
                    case "6":
                        return;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }
            }
        }

        static void CreateAccount(AccountService accountService)
        {
            Console.Write("Enter account holder name: ");
            var name = Console.ReadLine();
            Console.Write("Enter initial balance: ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal initialBalance))
            {
                Console.WriteLine("Invalid amount. Please enter a valid number.");
                return;
            }

            Console.WriteLine("Select account type:");
            Console.WriteLine("1. Savings");
            Console.WriteLine("2. Checking");
            var accountTypeChoice = Console.ReadLine();
            AccountType accountType;
            switch (accountTypeChoice)
            {
                case "1":
                    accountType = AccountType.Savings;
                    break;
                case "2":
                    accountType = AccountType.Checking;
                    break;
                default:
                    Console.WriteLine("Invalid account type. Defaulting to Savings.");
                    accountType = AccountType.Savings;
                    break;
            }

            var account = accountService.CreateAccount(name, initialBalance, accountType);
            Console.WriteLine($"Account created successfully. Account Number: {account.AccountNumber}");
        }

        static void Deposit(AccountService accountService)
        {
            Console.Write("Enter account number: ");
            if (!int.TryParse(Console.ReadLine(), out int accountNumber))
            {
                Console.WriteLine("Invalid account number.");
                return;
            }

            Console.Write("Enter amount to deposit: ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal amount))
            {
                Console.WriteLine("Invalid amount.");
                return;
            }

            if (accountService.Deposit(accountNumber, amount))
            {
                Console.WriteLine("Deposit successful.");
            }
            else
            {
                Console.WriteLine("Deposit failed. Account not found.");
            }
        }

        static void Withdraw(AccountService accountService)
        {
            Console.Write("Enter account number: ");
            if (!int.TryParse(Console.ReadLine(), out int accountNumber))
            {
                Console.WriteLine("Invalid account number.");
                return;
            }

            Console.Write("Enter amount to withdraw: ");
            if (!decimal.TryParse(Console.ReadLine(), out decimal amount))
            {
                Console.WriteLine("Invalid amount.");
                return;
            }

            if (accountService.Withdraw(accountNumber, amount))
            {
                Console.WriteLine("Withdrawal successful.");
            }
            else
            {
                Console.WriteLine("Withdrawal failed. Check account balance or account number.");
            }
        }

        static void CheckBalance(AccountService accountService)
        {
            Console.Write("Enter account number: ");
            if (!int.TryParse(Console.ReadLine(), out int accountNumber))
            {
                Console.WriteLine("Invalid account number.");
                return;
            }

            var balance = accountService.CheckBalance(accountNumber);
            Console.WriteLine($"Current balance: {balance}");
        }

        static void ViewTransactionHistory(AccountService accountService)
        {
            Console.Write("Enter account number: ");
            if (!int.TryParse(Console.ReadLine(), out int accountNumber))
            {
                Console.WriteLine("Invalid account number.");
                return;
            }

            var transactions = accountService.GetTransactionHistory(accountNumber);
            if (transactions == null || transactions.Count == 0)
            {
                Console.WriteLine("No transactions found.");
                return;
            }

            Console.WriteLine("Transaction History:");
            foreach (var transaction in transactions)
            {
                Console.WriteLine($"ID: {transaction.TransactionId}, Date: {transaction.Date}, Amount: {transaction.Amount}, Description: {transaction.Description}");
            }
        }
    }
}
