using System.Collections.Generic;

namespace BankingSystem.Models
{
    public class Account
    {
        public int AccountNumber { get; set; }
        public string AccountHolderName { get; set; }
        public decimal Balance { get; set; }
        public AccountType AccountType { get; set; }
        public List<Transaction> Transactions { get; set; }

        public Account(int accountNumber, string accountHolderName, decimal initialBalance, AccountType accountType)
        {
            AccountNumber = accountNumber;
            AccountHolderName = accountHolderName;
            Balance = initialBalance;
            AccountType = accountType;
            Transactions = new List<Transaction>();
        }
    }
}
