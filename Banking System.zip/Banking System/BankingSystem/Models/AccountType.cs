namespace BankingSystem.Models
{
    public enum AccountType
    {
        Savings,
        Checking
    }
}
