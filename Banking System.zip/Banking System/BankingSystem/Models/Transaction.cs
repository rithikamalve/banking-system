using System;

namespace BankingSystem.Models
{
    public class Transaction
    {
        public int TransactionId { get; set; }
        public DateTime Date { get; set; }
        public decimal Amount { get; set; }
        public string Description { get; set; }

        public Transaction(int transactionId, DateTime date, decimal amount, string description)
        {
            TransactionId = transactionId;
            Date = date;
            Amount = amount;
            Description = description;
        }
    }
}
