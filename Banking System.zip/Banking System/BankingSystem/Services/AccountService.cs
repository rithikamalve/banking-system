using BankingSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace BankingSystem.Services
{
    public class AccountService
    {
        private readonly List<Account> _accounts;
        private int _nextAccountNumber;
        private int _nextTransactionId;

        public AccountService()
        {
            _accounts = new List<Account>();
            _nextAccountNumber = 1;
            _nextTransactionId = 1;
        }

        public Account CreateAccount(string accountHolderName, decimal initialBalance, AccountType accountType)
        {
            var account = new Account(_nextAccountNumber++, accountHolderName, initialBalance, accountType);
            _accounts.Add(account);
            return account;
        }

        public bool Deposit(int accountNumber, decimal amount)
        {
            var account = _accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            if (account == null)
                return false;

            account.Balance += amount;
            var transaction = new Transaction(_nextTransactionId++, DateTime.Now, amount, "Deposit");
            account.Transactions.Add(transaction);
            return true;
        }

        public bool Withdraw(int accountNumber, decimal amount)
        {
            var account = _accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            if (account == null || account.Balance < amount)
                return false;

            account.Balance -= amount;
            var transaction = new Transaction(_nextTransactionId++, DateTime.Now, amount, "Withdrawal");
            account.Transactions.Add(transaction);
            return true;
        }

        public decimal CheckBalance(int accountNumber)
        {
            var account = _accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            return account?.Balance ?? 0;
        }

        public List<Transaction> GetTransactionHistory(int accountNumber)
        {
            var account = _accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            return account?.Transactions ?? new List<Transaction>();
        }
    }
}
